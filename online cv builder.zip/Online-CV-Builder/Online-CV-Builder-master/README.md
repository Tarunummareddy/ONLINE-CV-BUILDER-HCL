﻿# resume-builder
https://testanalytics-5e6e3.web.app/

# Use
* Can create new resumes using templates.
* Can edit them.
* Can manage them via a dashboard .
* Editable fields include 
*           Job
*           Education
*           Skills
*           Language
*           Personel details
*           Photo Upload

# Designed by
Vabilisetti Naga Yashvanth kumar
 


